
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="Grabify IP Logger URL Shortener tracks IP address and locations. Track IP addresses, find IPs from Facebook, Twitter, friends on other sites.">
<meta name="keywords" content="grabify, ip logger, iplogger, url shortener, link shortener, ip, grabtheirip, grab ip, ip address, track ip, IP tracker, Facebook IP, Twitter IP">
<meta property="fb:admins" content="1307078942" />
<meta name="theme-color" content="#2C3E50">
<meta name="csrf-token" content="PqzWai1oa9e7D9rql6W9JCE6QxCAMgkUOQuyiGUx">
<meta property="og:type" content="website" />
<meta property="og:site_name" content="404 - Grabify IP Logger &amp; URL Shortener" />
<meta property="og:title" content="404 - Grabify IP Logger &amp; URL Shortener" />
<meta property="og:description" content="Grabify IP Logger URL Shortener allows to track IP address and track location, provides IP lookup and IP grabber services and let you check what is my ip, use website counters and IP informers." />
<meta property="og:image" content="https://grabify.link/images/196.png" />
<meta property="og:image:width" content="196" />
<meta property="og:image:height" content="196" />
<meta property="og:image:alt" content="404 - Grabify IP Logger URL Shortener - Log and Track IP addresses" />
<meta property="og:url" content="https://grabify.link/tiny.cc" />
<title>404 - Grabify IP Logger &amp; URL Shortener</title>
<link rel="canonical" href="https://grabify.link/tiny.cc">
<link rel="shortcut icon" href="https://grabify.link/images/favicon.ico">
<link rel="icon" type="image/png" sizes="192x192" href="https://grabify.link/images/196.png">
<script type="application/ld+json">
		{
		  "@context": "http://schema.org",
		  "@type": "Organization",
		  "name": "Grabify",
		  "url": "https://grabify.link/",
		  "logo": "https://grabify.link/images/196.png"
		}

    </script>
<link href="/css/all.css?id=ab4670ca7cfa50e69889" rel="stylesheet">
<script src='https://hcaptcha.com/1/api.js' async defer></script>
<script src="https://grabify.link/js/jquery-3.3.1.min.js"></script>
<script src="/js/ads.js"></script>
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<script>
        (adsbygoogle = window.adsbygoogle || []).push({
            google_ad_client: "ca-pub-2948634054145662",
            enable_page_level_ads: true
        });
    </script>
<script async src="//cdn.publift.com/fuse/tag/2/1218/fuse.js"></script>
</head>
<body id="page-top" class="index">
<script>
    (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
        (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
        m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
    })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

    ga('create', 'UA-53729676-1', 'auto');
    ga('send', 'pageview');
</script><script>
    (function(h,o,t,j,a,r){
        h.hj=h.hj||function(){(h.hj.q=h.hj.q||[]).push(arguments)};
        h._hjSettings={hjid:1523499,hjsv:6};
        a=o.getElementsByTagName('head')[0];
        r=o.createElement('script');r.async=1;
        r.src=t+h._hjSettings.hjid+j+h._hjSettings.hjsv;
        a.appendChild(r);
    })(window,document,'https://static.hotjar.com/c/hotjar-','.js?sv=');
</script>
<div id="ab" class="ab_container" style="display: none; background-color: rgba(0, 0, 0, 0.65);">
<div class="css8">
<div class="css1 css2" style="background-color: rgb(255, 255, 255);">
<div>
<div id="step1">
<h3 class="title" style="color: rgb(44, 62, 80);">It looks like you're using an adblocker!</h3>
<div class="description" style="color: rgb(44, 62, 80);">We use ads to keep our content free. Please
consider supporting us by turning off your adblocker.
</div>
<button class="button" onclick="continueBtn()" style="color: rgb(244, 247, 249); background-color: rgb(23, 188, 156);">Show me how to
whitelist →
</button>
</div>
<div class="ab_footer" style="background-color: rgba(44, 62, 80, 0.2); color: rgb(44, 62, 80);">
<span class="css11">
<a class="css12" style="color: rgb(44, 62, 80);">Continue without disabling</a>
</span>
<span class="css13">|</span>
<span class="css14">Experiencing issues? <a class="css15" href="https://www.facebook.com/GrabifyLogger/" target="_blank" style="color: rgb(44, 62, 80);">Report a problem</a></span>
</div>
</div>
</div>
</div>
</div>

<nav class="navbar navbar-default navbar-fixed-top">
<div class="container">

<div class="navbar-header page-scroll">
<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
<span class="sr-only">Toggle navigation</span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
</button>
<a class="navbar-brand" href="/">Grabify IP Logger</a>
</div>

<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
<ul class="nav navbar-nav navbar-right">
<li class="hidden">
<a href="#page-top"></a>
</li>
<li class="dropdown page-scroll">
<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Tools <span class="caret"></span></a>
<ul class="dropdown-menu">
<li><a href="https://grabify.link/ip-lookup">IP Lookup</a></li>
<li><a href="https://grabify.link/image">Invisible Image logger</a></li>
<li><a href="https://grabify.link/expander">URL Expander</a></li>
<li><a href="https://api.grabify.link/">API</a></li>
</ul>
</li>
<li class="page-scroll">
<a href='https://grabify.link/login'>Login</a>
</li>
<li class="page-scroll">
<a href='https://grabify.link/register'>Register</a>
</li>
</ul>
</div>

</div>

</nav><header>
<div class="container">
<h1>404</h1>
<p>The page you are looking for cannot be found.</p>
<br>
</div>
</header>
<div class="mobile_sticky_ad">

<div class div data-fuse="21842488990"></div>
<style>
            .mobile_sticky_ad {
                visibility: hidden;
            }

            @media  screen and (max-width: 1022px) {
                .mobile_sticky_ad {
                    height: fit-content;
                    width: 100%;
                    background-color: #2c3e50;
                    bottom: 0;
                    margin: 0 auto;
                    visibility: visible;
                    position: fixed;
                    z-index: 2000000001;
                }

                .cookiealert {
                    padding-bottom: 60px;
                }

                .text-center .footer-below {
                    padding-bottom: 70px;
                }

                .scroll-top {
                    margin-bottom: 55px;
                }

                .modal-dialog {
                    margin-bottom: 60px;
                }
            }
        </style>
</div>

<footer class="text-center">
<div class="footer-above">
<div class="container">
<div class="row">
<div class="footer-col col-md-4">
<h3>Social</h3>
<ul class="list-inline">
<li>
<a href="https://www.facebook.com/GrabifyLogger/" class="btn-social btn-outline"><i class="fa fa-fw fa-facebook"></i></a>
</li>
<li>
<a href="https://twitter.com/GrabifyDOTlink" class="btn-social btn-outline"><i class="fa fa-fw fa-twitter"></i></a>
</li>
</ul>
</div>
<div class="footer-col col-md-4">
<h3>Around the Web</h3>
<ul class="list-inline">
<li>
<a href="https://www.facebook.com/GrabifyLogger/" class="btn-social btn-outline"><i class="fa fa-fw fa-facebook"></i></a>
</li>
<li>
<a href="http://jlynx.net/" class="btn-social btn-outline"><i class="fa fa-fw fa-globe"></i></a>
</li>
<li>
<a href="https://twitter.com/jLynx_DarkN3ss" class="btn-social btn-outline"><i class="fa fa-fw fa-twitter"></i></a>
</li>
</ul>
</div>
<div class="footer-col col-md-4">
<h3>FAQ</h3>
<p>Please check out our Frequently asked questions here: <a href="https://grabify.link/faq">FAQ</a>.</p>
</div>
</div>
</div>
</div>
<div class="footer-below">
<div class="container">
<div class="row">
<div class="col-lg-12">
Copyright &copy; Grabify 2020<br><a href="https://grabify.link/privacy" target="_blank">Privacy</a> - <a href="https://grabify.link/tos" target="_blank">TOS</a> - <a href="https://grabify.link/removeme">Remove
My Data</a>
</div>
</div>
</div>
</div>
</footer>

<div class="alert alert-dismissible text-center cookiealert" role="alert">
<div class="cookiealert-container">
<b>Do you like cookies?</b> &#x1F36A; We use cookies to ensure you get the best experience on our website. <a href="/privacy#cookie" target="_blank">Learn more here</a>
<button type="button" class="btn btn-primary btn-sm acceptcookies" aria-label="Close">
I agree
</button>
</div>
</div>

<script>
    (function () {
        "use strict";

        var cookieAlert = document.querySelector(".cookiealert");
        var acceptCookies = document.querySelector(".acceptcookies");
        var footerCookie = document.querySelector("footer");

        cookieAlert.offsetHeight; // Force browser to trigger reflow (https://stackoverflow.com/a/39451131)

        if (!getCookie("acceptCookies")) {
            console.log("Showing it");
            cookieAlert.classList.add("show");
            footerCookie.classList.add("footer-cookie");

            //    padding-bottom: 55px;
        }

        acceptCookies.addEventListener("click", function () {
            setCookie("acceptCookies", true, 360);
            cookieAlert.classList.remove("show");
            footerCookie.classList.remove("footer-cookie");
        });
    })();

    // Cookie functions stolen from w3schools
    function setCookie(cname, cvalue, exdays) {
        var d = new Date();
        d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
        var expires = "expires=" + d.toUTCString();
        document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
    }

    function getCookie(cname) {
        var name = cname + "=";
        var decodedCookie = decodeURIComponent(document.cookie);
        var ca = decodedCookie.split(';');
        for (var i = 0; i < ca.length; i++) {
            var c = ca[i];
            while (c.charAt(0) === ' ') {
                c = c.substring(1);
            }
            if (c.indexOf(name) === 0) {
                return c.substring(name.length, c.length);
            }
        }
        return "";
    }
</script>

<div class="scroll-top page-scroll visible-xs visible-sm">
<a class="btn btn-primary" href="#page-top">
<i class="fa fa-chevron-up"></i>
</a>
</div>
<script src="/js/all.js?id=52535e0a408dac9e857f"></script>

<script type="text/javascript">
        var Tawk_API = Tawk_API || {}, Tawk_LoadStart = new Date();
        (function () {
            var s1 = document.createElement("script"), s0 = document.getElementsByTagName("script")[0];
            s1.async = true;
            s1.defer = true;
            s1.src = 'https://embed.tawk.to/56dbf56bfd8c937066739b91/default';
            s1.charset = 'UTF-8';
            s1.setAttribute('crossorigin', '*');
            s0.parentNode.insertBefore(s1, s0);
        })();
    </script>

<script>
    if(window.location.hash) {
        var hash = window.location.hash.substring(1);
        if(hash === "ShowBlocker") {
            document.getElementById("ab").style.display = "block";

            document.body.classList.add("stop-scrolling");
        }
    }

    if(window.canRunAds === undefined){
        if(getCookie('ckstp') !== '1') {
            document.getElementById("ab").style.display = "block";
            document.body.classList.add("stop-scrolling");
        }
    }

    function continueBtn() {
        document.getElementById("step1").outerHTML = '<div class="iframe_container" style="color: rgb(44, 62, 80);"><iframe id="iframe_Id" class="frame" src="/adblockcheck/instructions?textColor=rgba(44%2C62%2C80%2C1)&amp;btnColor=23%2C188%2C156%2C1&amp;btnTextColor=244%2C247%2C249%2C1" height="468" width="100%" allowtransparency="true"></iframe></div>';
    }


    var anchors = document.getElementsByClassName('css12');
    for(var i = 0; i < anchors.length; i++) {
        var anchor = anchors[i];
        anchor.onclick = function() {
            setCookie('ckstp', '1', 100)
            document.getElementById("ab").style.display = "none";
            document.body.classList.remove("stop-scrolling");
        }
    }

    function setCookie(name,value,days) {
        var expires = "";
        if (days) {
            var date = new Date();
            date.setTime(date.getTime() + (days*24*60*60*1000));
            expires = "; expires=" + date.toUTCString();
        }
        document.cookie = name + "=" + (value || "")  + expires + "; path=/";
    }
    function getCookie(name) {
        var nameEQ = name + "=";
        var ca = document.cookie.split(';');
        for(var i=0;i < ca.length;i++) {
            var c = ca[i];
            while (c.charAt(0)==' ') c = c.substring(1,c.length);
            if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
        }
        return null;
    }
</script>
</body>
</html>
